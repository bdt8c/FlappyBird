﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BirdController : MonoBehaviour {
    public static BirdController Instance;

    public float bounceForce;
    private Rigidbody2D myBody;
    private Animator anim;
    [SerializeField]
    private AudioSource audioSource;
    [SerializeField]
    private AudioClip flyClip = null, pingClip=null, diedClip=null;
    private bool isAlive;
    private bool didFlap;
    public float flag = 0;
    public int score = 0;
    private GameObject spawner;
    //private float jumpelocity;
    //float g = -9.8f;
    // Use this for initialization
    void Awake() {
        myBody = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        isAlive = true;
        _MakeInstance();
        spawner = GameObject.Find("Spawner Pipe");
    }
    void _MakeInstance()
    {
        if(Instance == null)
        {
            Instance = this;
        }
    }
    // Update is called once per frame
    void FixedUpdate() {
        _BirdMoveMent();
    }
    void _BirdMoveMent()
    {
        if (isAlive == true)
        {
            if (didFlap)
            {
                didFlap = false;
                myBody.velocity = new Vector2(myBody.velocity.x, bounceForce);
                audioSource.PlayOneShot(flyClip);
            }
        }
       
        //transform.position += Vector3.up * (jumpelocity * Time.deltaTime /2);
        //jumpelocity += g * Time.deltaTime;

        // if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
        // {
        //jumpelocity = 2f;
        //  myBody.velocity = new Vector2(myBody.velocity.x, bounceForce);
        //   audioSource.PlayOneShot(flyClip);

        // }
        if (myBody.velocity.y > 0)
        {
            float angel = 0;
            angel = Mathf.Lerp(0, 90, myBody.position.y / 6);
            transform.rotation = Quaternion.Euler(0, 0, angel);
        }
        else if (myBody.velocity.y == 0)
        {
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        else if (myBody.velocity.y < 0)
        {
            float angel = 0;
            angel = Mathf.Lerp(0, -90, -myBody.position.y / 6);
            transform.rotation = Quaternion.Euler(0, 0, angel);
        }
    }
    public void Flapbutton()
    {
        didFlap = true;
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "PipeHolder")
        {
            score++;
            Debug.Log("" + score.ToString());
            if (GamePlayController.Instance != null)
            {
                GamePlayController.Instance._Setscore(score);
            }
            audioSource.PlayOneShot(pingClip);
        }
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Pipe" || other.gameObject.tag == "Ground")
        {
            flag = 1;
            if (isAlive)
            {
                isAlive = false;
                
            }
                
            audioSource.PlayOneShot(diedClip);
            anim.SetTrigger("die");
            Destroy(spawner);
            diedClip = null;
            if(GamePlayController.Instance != null)
            {

                GamePlayController.Instance.BirDieShowPanel(score);

            }
        }
    }
   

}

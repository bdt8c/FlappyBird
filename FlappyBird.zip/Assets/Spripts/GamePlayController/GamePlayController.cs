﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GamePlayController : MonoBehaviour {
    public static GamePlayController Instance;
    [SerializeField]

    private Button InstuctionButton;
    [SerializeField]

    public Text scoreText, endScoreText, bestScoreText;
    [SerializeField]

    private GameObject gameOverPanel, pausePanel, pauseButton,flashdie;
    [SerializeField]
    private GameObject Medial, Silver, Gold;

    void Awake()
    {
        Time.timeScale = 0;
        _MakeInstance();
        Medial.SetActive(false);
        Silver.SetActive(false);
        Gold.SetActive(false);
       // flashdie.SetActive(false);
    }
    public void _MakeInstance()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }
    public void _InstructionButton()
    {
        Time.timeScale = 1;
        pauseButton.SetActive(true);
        InstuctionButton.gameObject.SetActive(false);
    }
    public void _Setscore(int score)
    {
        scoreText.text = "" + score.ToString();
    }
    public void BirDieShowPanel(int score)
    {
        float check = Mathf.Round(GameManagers.instance.GetHightScore() / 2);
        StartCoroutine(showPanel());
        pauseButton.SetActive(false);
        endScoreText.text = "" + score;
        if (score == GameManagers.instance.GetHightScore())
        {
            GameManagers.instance.GetHightScore(score);
            Gold.SetActive(true);
        }else
        if(score == check)
        {
            Silver.SetActive(true);
            Gold.SetActive(false);
        }else if(score < GameManagers.instance.GetHightScore())
        {
            Silver.SetActive(false);
            Gold.SetActive(false);
            Medial.SetActive(true);
        }
        bestScoreText.text = "" + GameManagers.instance.GetHightScore();
        //Debug.Log("check:" + check.ToString());
    }
    IEnumerator showPanel()
    {


        flashdie.SetActive(true);
        yield return new WaitForSeconds(0.1f);
        flashdie.SetActive(false);
        yield return new WaitForSeconds(2);
        gameOverPanel.SetActive(true);
      
        
    }
   
        public void MenuButton()
        {
            SceneManager.LoadScene("GameMenu");
            pauseButton.SetActive(true);
        }
        public void ResetButton()
        {
            SceneManager.LoadScene("GamePlay");
            pauseButton.SetActive(true);
        }
        public void PauseButton()
        {
            Time.timeScale = 0;
            pausePanel.SetActive(true);
        }
        public void ResumeButton()
        {
            Time.timeScale = 1;
            pausePanel.SetActive(false);
        }

    }


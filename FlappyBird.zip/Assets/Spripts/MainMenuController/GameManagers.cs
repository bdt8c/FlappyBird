﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManagers : MonoBehaviour {

    public static GameManagers instance;
    private const string HIGH_SCORE = "Hight Score";
    void Awake()
    {
        MakeSingleInstance();
        IsGameStartForTheFistTime();
    }
    public void MakeSingleInstance()
    {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }
    void IsGameStartForTheFistTime()
    {
        if (!PlayerPrefs.HasKey("IsGameStartForTheFistTime"))
        {
            PlayerPrefs.SetInt(HIGH_SCORE, 0);
            PlayerPrefs.SetInt("IsGameStartForTheFistTime", 0);
        }
    }
    public void GetHightScore(int score)
    {
        PlayerPrefs.SetInt(HIGH_SCORE, score);
    }
    public float GetHightScore()
    {
        return PlayerPrefs.GetInt(HIGH_SCORE);
    }
}

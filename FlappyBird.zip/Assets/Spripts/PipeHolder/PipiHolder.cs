﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PipiHolder : MonoBehaviour {
    public float speed;
   
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        _PipeMovement();
        if (BirdController.Instance!= null)
        {
            if (BirdController.Instance.flag == 1)
            {
                Destroy(GetComponent<PipiHolder>());
               
            }
        }
    }
    void _PipeMovement()
    {
        Vector3 temp = transform.position;
        temp.x -= speed * Time.deltaTime;
        transform.position = temp;
    }
     void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Detroy")
        {
            Destroy(gameObject);
        }
    }
}
